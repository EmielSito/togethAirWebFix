package com.realdolmen.group7.domain.payment;

/**
 * Created by ESOBG49 on 6/11/2017.
 */
public enum PaymentMethod {
}

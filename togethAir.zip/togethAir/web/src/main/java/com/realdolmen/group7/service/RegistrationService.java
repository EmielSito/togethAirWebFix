package com.realdolmen.group7.service;

import javax.enterprise.context.ApplicationScoped;

/**
 * Created by ESOBG49 on 7/11/2017.
 */


@ApplicationScoped
public class RegistrationService {











}

package com.realdolmen.group7.repository;

/**
 * Created by PMTBF30 on 7/11/2017.
 */
public class PartnerRepository {
}
